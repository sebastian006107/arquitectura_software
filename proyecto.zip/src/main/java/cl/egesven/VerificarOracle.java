package cl.egesven;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class VerificarOracle {
    public static void main(String[] args) {
        String url = "jdbc:oracle:thin:@localhost:1521/FREEPDB1";
        String user = "egesven";
        String pass = "egesven123";

        System.out.println("========== Verificando Oracle eGESVEN ==========\n");

        try (Connection conn = DriverManager.getConnection(url, user, pass)) {
            System.out.println("[OK] Conexion exitosa a Oracle\n");

            System.out.println("--- Tablas en el esquema eGESVEN ---");
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT TABLE_NAME FROM USER_TABLES ORDER BY TABLE_NAME");
            int count = 0;
            while (rs.next()) {
                System.out.println("  " + rs.getString("TABLE_NAME"));
                count++;
            }

            if (count == 0) {
                System.out.println("\n[AVISO] No hay tablas. Debes ejecutar:");
                System.out.println("  docker exec -i oracle-free sqlplus egesven/egesven123@FREEPDB1 < eGESVEN_oracle.sql");
            } else {
                System.out.println("\n[OK] " + count + " tablas encontradas.");
            }

            System.out.println("\n--- Datos en PRODUCTO ---");
            rs = stmt.executeQuery("SELECT ID_PRODUCTO, NOMBRE, PRECIO, STOCK FROM PRODUCTO");
            int prodCount = 0;
            while (rs.next()) {
                System.out.printf("  [%d] %s - $%,.0f (Stock: %d)%n",
                    rs.getInt(1), rs.getString(2), rs.getDouble(3), rs.getInt(4));
                prodCount++;
            }
            if (prodCount == 0) {
                System.out.println("  (sin productos)");
            }

            System.out.println("\n--- Datos en MEDIO_PAGO ---");
            rs = stmt.executeQuery("SELECT ID_MEDIO_PAGO, TIPO, ESTADO FROM MEDIO_PAGO");
            while (rs.next()) {
                System.out.printf("  [%d] %s (%s)%n", rs.getInt(1), rs.getString(2), rs.getString(3));
            }

            System.out.println("\n[OK] Verificacion completa. El proyecto esta listo para ejecutarse.");
        } catch (Exception e) {
            System.out.println("[ERROR] " + e.getMessage());

            if (e.getMessage() != null && e.getMessage().contains("ORA-01017")) {
                System.out.println("  => Usuario/contraseña incorrectos");
            } else if (e.getMessage() != null && e.getMessage().contains("ORA-12514")) {
                System.out.println("  => La base FREEPDB1 no esta disponible. Intenta FREEPDB1 o XEPDB1");
            } else if (e.getMessage() != null && e.getMessage().contains("ORA-01918")) {
                System.out.println("  => El usuario 'egesven' no existe. Ejecuta el script SQL primero.");
            } else {
                System.out.println("  => Verifica que el contenedor Docker este corriendo.");
                System.out.println("     docker ps | grep oracle");
            }
        }
    }
}
